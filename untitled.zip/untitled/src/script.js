document.querySelectorAll('.box').forEach(box => {
    box.addEventListener('mouseenter', () => {
        box.style.transform = "scale(1.1)";
        box.style.transition = "0.3s";
    });
    box.addEventListener('mouseleave', () => {
        box.style.transform = "scale(1)";
    });
});